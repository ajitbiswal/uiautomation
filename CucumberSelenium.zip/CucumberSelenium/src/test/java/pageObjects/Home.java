package pageObjects;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import framework.Coreoperations;


public class Home {
	
	Coreoperations core = new Coreoperations();
	public void enterBank(String Bank) {
		try {
			core.safeSelectFromDropDownByValue(By.xpath(core.getReference("accountEntitlementPage.bank")),Bank);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}


	
	public void enterBranch(String Branch) throws IOException{
		core.enterText(Branch,By.xpath(core.getReference("cst.branch")),Branch);
		
	}
	
}
