package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import framework.Coreoperations;


public class Home {
	Coreoperations core = new Coreoperations();
	public void clickHomeMenu(String webelement){
		String value1 = core.GetPropertyValue("ajit");		

}
	
}
