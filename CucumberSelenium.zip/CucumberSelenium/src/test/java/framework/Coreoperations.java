package framework;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Coreoperations {
	WebDriver wd;
	public void openBrowser(String browser){
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Ajit\\Downloads\\geckodriver.exe");
		wd = new FirefoxDriver();
		wd.get("https://www.amazon.in/");
		
	}
	
	public int clickOnElement(By elementLocator){
			try {
			WebElement element = findElementSafe(elementLocator);
			element.click();
		}catch (Exception e){
			//exceptionHandler(e,"Tried to click on an element",elementLocator.toString();
		}
		return 0;
	}
		
		public WebElement findElementSafe(By elementLocator) {
			 
			WebDriverWait wait = new WebDriverWait(wd, 10);
			 WebElement element1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("  ")));
			// TODO Auto-generated method stub
			return element1;
			
		}

		public String GetPropertyValue(String string) {
			String value = "ajit";
			return value;
		}

//
//	
//	public static void main(String[] args) {
//		Coreoperations op = new Coreoperations();
//		op.openBrowser("firefox");
//		System.out.println("this is test");
////		
////
//	}
}

	