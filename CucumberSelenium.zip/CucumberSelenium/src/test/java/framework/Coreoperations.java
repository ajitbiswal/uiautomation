package framework;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Coreoperations {
	WebDriver wd;
	
	public void openBrowser(String browser,String Url){
		if(browser=="Firefox"){
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Ajit\\Downloads\\geckodriver.exe");
		wd = new FirefoxDriver();
		wd.get(Url);
		}
	}
	
	public int clickOnElement(By elementLocator){
			try {
			WebElement element = findElementSafe(elementLocator);
			element.click();
		}catch (Exception e){
			//exceptionHandler(e,"Tried to click on an element",elementLocator.toString();
		}
		return 0;
	}
		
		public WebElement findElementSafe(By elementLocator) {
			 
			WebDriverWait wait = new WebDriverWait(wd, 10);
			 WebElement element1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("  ")));
			// TODO Auto-generated method stub
			return element1;
			
		}

		

		

		
		public String getReference(String propKey) throws IOException{
			File file = new File("file//path");
			FileInputStream fileInput = new FileInputStream(file);
			Properties prop = new Properties();
			prop.load(fileInput);
			String value = prop.getProperty(propKey);
			return value;
			
		}
//
//	
//	public static void main(String[] args) {
//		Coreoperations op = new Coreoperations();
//		op.openBrowser("firefox");
//		System.out.println("this is test");
////		
////
//	}

public void enterText(String text,By elementLocator, String branch){
			WebElement element = null;
			element.sendKeys(text);
			
		}
		


public void safeSelectFromDropDownByValue(By locator, String visibleText) {
	// TODO Auto-generated method stub
	
}}
	