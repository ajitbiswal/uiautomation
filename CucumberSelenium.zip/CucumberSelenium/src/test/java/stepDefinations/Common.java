package stepDefinations;

import org.openqa.selenium.By;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import framework.Coreoperations;
import pageObjects.Home;

public class Common {
	Coreoperations core = new Coreoperations();
	Home home = new Home();
	
	@When("^user searches a product on homepage$")
	public void user_searches_a_product_on_homepage() throws Throwable {
		core.openBrowser("firefox","https://www.amazon.in/");	
		
		String elementLocator = null;
		//home.clickHomeMenu(elementLocator);
		System.out.println("test2");
	    //throw new PendingException();
	}

	@Then("^User should be able to find the searched product$")
	public void User_should_be_able_to_find_the_searched_product() throws Throwable {
		System.out.println("fest3");
	    //throw new PendingException();
	}

	@When("^user click on check out$")
	public void user_click_on_check_out() throws Throwable {
		System.out.println("test5");
	    //throw new PendingException();
	}
	@Then("^User should be able to view the checkout$")
	public void User_should_be_able_to_view_the_checkout() throws Throwable {
		System.out.println("fest6");
	    //throw new PendingException();
	}

}




