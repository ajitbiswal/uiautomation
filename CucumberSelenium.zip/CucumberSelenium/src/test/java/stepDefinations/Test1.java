package stepDefinations;

import org.testng.annotations.Test;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test1 {

	@Given("^User is logged into amazon site$")
	public void User_is_logged_into_amazon_site() throws Throwable {
	    System.out.println("test1");
	    //throw new PendingException();
	}

		
	
	@Given("^User is logged into amazon site and found the searched product$")
	public void User_is_logged_into_amazon_site_and_found_the_searched_product() throws Throwable {
		System.out.println("test4");
	    //throw new PendingException();
	}

	
	




}
