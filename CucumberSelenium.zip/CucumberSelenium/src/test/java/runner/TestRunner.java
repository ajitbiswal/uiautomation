package runner;

import java.io.File;

import org.junit.runner.RunWith;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;
//@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/test/resources/features"}
,plugin = ("com.cucumber.listener.ExtentCucumberFormatter:C:\\Users\\Ajit\\workspace1\\CucumberSelenium\\test-output\\report.html")
,glue={"stepDefinations"},tags={"@regressiontest"})
//public class TestRunner{
public class TestRunner extends AbstractTestNGCucumberTests{
	ExtentReports reports;
	ExtentTest testInfo;
	//ExtentHtmlReporter htmlReporter;
    String xFilePath;
    String sheetName;
@AfterClass
public static void reportSetup(){
	Reporter.loadXMLConfig(new File("C:\\Users\\Ajit\\workspace1\\CucumberSelenium\\src\\test\\resources\\extent-config.xml"));
	Reporter.setSystemInfo("username",System.getProperty("user.name"));
	Reporter.setSystemInfo("Time Zone",System.getProperty("user.timezone"));
	Reporter.setSystemInfo("username",System.getProperty("user.name"));
	
}
	
	
}
