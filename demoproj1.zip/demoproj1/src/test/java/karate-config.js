function fn() {  

//set up runtime variables based on environment
  //get system property 'karate.env'
  var env = karate.env;
 var testtp = karate.properties['testtype']

  if (!env) { env = 'dev'; }  // default when karate.env not set

	//base config
	var config = {
		  env: env,
		  baseUrl: 'https://www.crcind.com:443/csp/samples/SOAP.Demo.cls',
		folderdatestamp: returnDate(),
		actionkey: 'http://tempuri.org/SOAP.Demo.',
		//testtp : testtype	  
	}
	//switch environment
	if (env == 'dev') {		
		config.baseUrl = 'https://www.crcind.com:443/csp/samples/SOAP.Demo.cls';
		config.testtp = testtp
	} 
	else if (env == 'qual') { //Pre-production environment settings
		config.baseUrl = 'https://qualapi.abc123.example.com/api/v1/validate/customerid';
	}
	
//	  var config = { 
//	    folderdatestamp: returnDate(),
//	    actionkey: 'http://tempuri.org/SOAP.Demo.'
//	  };
	  
  karate.configure('connectTimeout', 5000);
  karate.configure('readTimeout', 5000);
  return config;
}

function returnDate(){
var today = new Date();
var dd = today.getDate();

var mm = today.getMonth()+1;
var yyyy = today.getFullYear();
if(dd<10)
{
   dd='0'+dd;
}

if(mm<10)
{
   mm='0'+mm;
}
return dd+''+mm+''+yyyy
}
