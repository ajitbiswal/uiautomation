package demoproj1;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.intuit.karate.KarateOptions;
import com.intuit.karate.junit4.Karate;






@RunWith(Karate.class)
//If you want to run a specific features
@KarateOptions(features = "classpath:feature/add3.feature",tags="~@beforedeployment")
public class ApiTestRunner {
	@BeforeClass
    public static void before() {
        System.setProperty("karate.env","dev");
        System.setProperty("testtype","afterdeployment");
  
    }

}
