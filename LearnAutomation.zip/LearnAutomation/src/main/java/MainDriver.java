import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import org.apache.poi.ss.usermodel.WorkbookFactory;

import AutomationFramework.DynamicTestNG;
import AutomationFramework.ExcelOperation;

public class MainDriver {
	static List<String> testCaseExecution = new ArrayList<String>();
	
	

	public static void main(String[] args) throws InvalidFormatException, IOException {
		ExcelOperation ex = new ExcelOperation();
		MainDriver md = new MainDriver();
		DynamicTestNG execute = new DynamicTestNG();	
		
		testCaseExecution = ex.testCaseExecute();
		execute.testNg(testCaseExecution);
	

	}

}
