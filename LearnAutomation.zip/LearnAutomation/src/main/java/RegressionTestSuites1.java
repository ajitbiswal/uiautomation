import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import AutomationFramework.ExcelOperation;
import AutomationFramework.Testcasereports;

public class RegressionTestSuites1 extends Testcasereports {
ExcelOperation exl;
String xFilePath = System.getProperty("user.dir")+"//InputSheet.xlsx";
String sheetName = "Regression1_TestData";
	
	//@Test(dataProvider="userData")
	//public void regression1_test1(String userName,String passWord,String date){
//testInfo=reports.createTest("demo test pass","This test case will demostrate the pass test case");
		//System.out.println("UserName"+userName);
		//System.out.println("Password"+passWord);
		//System.out.println("Date"+date);
		//testInfo.log(com.aventstack.extentreports.Status.INFO,"This test case will demostrate the pass test case");
		//System.out.println("this is test");
	//}
	
	//@Test(dataProvider="userData")
	//public void regression1_test2(String userName,String date1){
//testInfo=reports.createTest("demo test pass","This test case will demostrate the pass test case");
		//System.out.println("UserName"+userName);
		//System.out.println("Date"+date1);
		//testInfo.log(com.aventstack.extentreports.Status.INFO,"This test case will demostrate the pass test case");
		//System.out.println("this is test2");
	//}
//	<List<Integer> Map<String,String>>
	//public void regression1_test1(List<Map<String,String>> params ){
		//testInfo=reports.createTest("demo test pass","This test case will demostrate the pass test case");
		//System.out.println("UserName"+params.get(0).get("subname"));
		//System.out.println("Password"+params.get(0).get("subname"));
		
		//for(int i=0;i<params.size();i++){
			//if(params.get(i).get("Type").equalsIgnoreCase("Main")){
			//	System.out.println(params.get(i).get("A1"));
				//System.out.println(params.get(i).get("B1"));
				//System.out.println("Submit");
//				wait
			//}
			//if(!params.get(i).get("Type").equalsIgnoreCase("Main")){
				//System.out.println(params.get(i).get("A1"));
				//System.out.println(params.get(i).get("B1"));
			//}
			
		//}
		
//		System.out.println("Date"+date);
//		testInfo.log(com.aventstack.extentreports.Status.INFO,"This test case will demostrate the pass test case");
//		System.out.println("this is test");
		
	//}
	
	
	@Test ()
	public void regression1_test1(){
	//testInfo=reports.createTest("demo test pass","This test case will demostrate the pass test case");
		System.out.println("this is test");
	//Assert.assertTrue(false);
		//testInfo.log(com.aventstack.extentreports.Status.INFO,"This test case will demostrate the failed test case");
	}
	
//	@DataProvider(name="userData")
//	public Object[][] userGetData() throws InvalidFormatException, IOException{
//		Object[][] data =exl.testData(xFilePath,sheetName);
//		return data;
//		
//		
//	}
	
	//@DataProvider(name="userData")
	//public Object[][] userGetData() throws InvalidFormatException, IOException{
		
		//Object[][] data =exl.testData(xFilePath,sheetName);
		//Object[][] data = new Object[1][3];
		//data[0][0] = "ajit";
		//data[0][1] = "ajit";
		//data[0][2] = "ajit";
		//return data;
		
		
	//}
	
	
	
	
}
