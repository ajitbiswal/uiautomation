package AutomationFramework;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import AutomationFramework.ExcelOperation;
import ch.qos.logback.core.status.Status;

//import junit.framework.Assert;

//

public class Testcasereports {
	ExcelOperation exl;
	ExtentReports reports;
	ExtentTest testInfo;
	ExtentHtmlReporter htmlReporter;
    String xFilePath;
    String sheetName;
    
	@DataProvider(name="userData")
	public Object[][] userGetData() throws InvalidFormatException, IOException{
		
		Object[][] data =exl.testData(xFilePath,sheetName);
		return data;
		
		
	}

	@BeforeTest
	public void setup(){
	htmlReporter = new ExtentHtmlReporter(new File(System.getProperty("user.dir")+"/AutomationReports.html"));	
	System.out.println("file created");
	htmlReporter.loadXMLConfig(new File(System.getProperty("user.dir")+"/extent-config.xml"));
	reports = new ExtentReports();
	reports.attachReporter(htmlReporter);
	
	}
	
	/*@Test
	public void demoTestPass(){
		//testInfo=reports.createTest("demo test pass","This test case will demostrate the pass test case");
		Assert.assertTrue(true);
		testInfo.log(com.aventstack.extentreports.Status.INFO,"This test case will demostrate the pass test case");
	}
	
	@Test
	public void demoTestFail(){
		//testInfo=reports.createTest("demo test pass","This test case will demostrate the pass test case");
		Assert.assertTrue(false);
		testInfo.log(com.aventstack.extentreports.Status.INFO,"This test case will demostrate the failed test case");
	}*/
	
	//Use the reflection to dynamically get the methods
	
	@BeforeMethod
	public void register(Method method){
		String testName = method.getName();
		testInfo=reports.createTest(testName);
		
	}
	
	
	//ITestResult is the interface of the TESTNG which provided the runtime status of each test method
	
	@AfterMethod
	public void getResult(ITestResult result){
	
		if(result.getStatus()==ITestResult.FAILURE)
		{
			//testInfo.log(com.aventstack.extentreports.Status.FAIL,"The Test Method named as:"+result.getName()+"is failed");
			testInfo.fail(MarkupHelper.createLabel(result.getName()+"Test case failed",ExtentColor.RED));
			testInfo.fail(result.getThrowable());
		}
		else
			//testInfo.log(com.aventstack.extentreports.Status.PASS,"The Test Method named as:"+result.getName()+"is passed");
			testInfo.pass(MarkupHelper.createLabel(result.getName()+"Test case passed",ExtentColor.GREEN));
			//testInfo.pass(result.getThrowable());
	}
	
	@AfterSuite
	public void tearDown(){
		
		reports.flush();
	}
	
	/*@Test (groups = {"car"})
	public static void car1(){
		Assert.assertFalse(false);
		testInfo.
		System.out.println("this is car1");
			
	}
	
	@Test  (groups = {"car"})
	public static void car2(){
		Assert.assertTrue(true);
		
		System.out.println("this is car2");
			
	}
	
	
	@Test  (groups = {"truck"})
	public static void truck1(){
		
		System.out.println("this is truck1");
			
	}
	
	@Test  (groups = {"truck"})
	public static void truck2(){
		//Assert.assertEquals("A", "B");
		System.out.println("this is truck1");
			
	}

*/	
}



