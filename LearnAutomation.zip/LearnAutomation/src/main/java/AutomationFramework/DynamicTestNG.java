package AutomationFramework;
import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlInclude;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

public class DynamicTestNG {
	public void testNg(List<String> testCaseExecution){
		List<XmlInclude> methods = new ArrayList<XmlInclude>();
		XmlSuite suite = new XmlSuite();
		suite.setName("regressiosuite1");
		
		XmlTest test = new XmlTest(suite);
		test.setName("regressiontest1");
		
		XmlClass class1 = new XmlClass("RegressionTestSuites1");
		
		List<XmlClass> classes = new ArrayList<XmlClass>();
		classes.add(class1);
		
		test.setXmlClasses(classes);
		
		int j = 0;
				
		while(testCaseExecution.size()>j){
			methods.add(new XmlInclude(testCaseExecution.get(j)));
			j++;
			
				}
		
		class1.setIncludedMethods(methods);
		
		TestNG testNg = new TestNG();
		
		List<XmlSuite> list = new ArrayList<XmlSuite>();
		list.add(suite);
		
		testNg.setXmlSuites(list);
		testNg.run();
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
}