package AutomationFramework;

import java.util.HashMap;

public class CommonUtilities {
	
	
	//Store the inputs to the map 
	public HashMap<String,String> addDataToMap(HashMap<String,String> map,String Key,String Value){
		map.put(Key,Value);
		return map;		
	}
	
	
	public String readDataFromMap(HashMap map,String Key){
		map.get(Key);
		return Key;		
	}	
}
	
	
	

