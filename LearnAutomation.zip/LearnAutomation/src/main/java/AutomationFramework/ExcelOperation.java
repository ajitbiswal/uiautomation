package AutomationFramework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelOperation {
	
	//Read the testcase
	public List<String> testCaseExecute() throws InvalidFormatException, IOException{
		List<String> testcaselist = new ArrayList<String>();
		String path = System.getProperty("user.dir")+"//InputSheet.xlsx";
		FileInputStream file1 = new FileInputStream(path);
		Workbook wb = WorkbookFactory.create(file1);
		Sheet sh = wb.getSheet("Regression1");
		int rw = sh.getLastRowNum();
		Row rwdata;
		
		for(int i = 1;i<rw;i++){
		rwdata = sh.getRow(i);
		String testcase = rwdata.getCell(0).getStringCellValue();
		String status = rwdata.getCell(1).getStringCellValue();
		if(status.trim().equalsIgnoreCase("Y")){
			testcaselist.add(testcase);
		}
		//System.out.println(testcaselist);
	
		}
		return testcaselist;
	}
	
	//This method reas the excel sheet and provide the object array to data provider
	public Object[][] testData(String xlFilePath,String sheetName) throws InvalidFormatException, IOException{
		Object[][] excelData = null;
		FileInputStream fis = new FileInputStream(xlFilePath);
		Workbook wb1 = WorkbookFactory.create(fis);
		Sheet sh = wb1.getSheet(sheetName);
		int row = sh.getLastRowNum();
		int col = sh.getLastRowNum();
		excelData = new Object[row-1][col];
		
		for (int i =1;i<row;i++){
			Row row1 = sh.getRow(i);
			for (int j = 0;j<=col;j++){
				excelData[i][j] = row1.getCell(j).getStringCellValue();
			}
		}
		
		
		return excelData;
		
	}
	
}

//}	
	
	




